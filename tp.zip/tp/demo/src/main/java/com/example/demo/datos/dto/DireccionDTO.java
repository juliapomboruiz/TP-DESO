/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.demo.datos.dto;

/**
 *
 * @author I-MAG
 */
public class DireccionDTO {
    public String calle;
    public int numero;
    public int piso;
    public String departamento;
    public String codigoPostal;
    public String localidad;
    public String provincia;
    public String pais;
}
