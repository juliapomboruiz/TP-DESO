/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.demo.datos.dto;

import java.util.List;

public class EstadiaDTO {
    public int id;
    private int cantidad_huesped;
    private int cantidad_habitaciones;
    private int cantidad_dias;
    public String check_in;
    public String check_out;
    public List<HuespedDTO> huespedes;
}
